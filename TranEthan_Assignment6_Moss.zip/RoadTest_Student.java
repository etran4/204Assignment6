import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RoadTest_Student {
    private Road road;
    private Town town1;
    private Town town2;
    private int weight;
    private String name;
    
    @Before
    public void setUp() throws Exception {
        town1 = new Town("Town1");
        town2 = new Town("Town2");
        weight = 2;
        name = "Test";
        road = new Road(town1, town2, weight, name);
    }

    @Test
    public void testGetName() {
        assertEquals(road.getName(), "Test");
    }

    @Test
    public void testGetSource() {
        assertEquals(road.getSource(), town1);
    }

    @Test
    public void testGetDestination() {
        assertEquals(road.getDestination(), town2);
    }

    @Test
    public void testGetWeight() {
        assertEquals(road.getWeight(), weight);
    }

    @Test
    public void testContains() {
        assertTrue(road.contains(town1));
        assertTrue(road.contains(town2));
        assertFalse(road.contains(new Town("No")));
    }

    @Test
    public void testEquals() {
        assertEquals(road, new Road(town1, town2, weight, name));
        assertEquals(road, new Road(town2, town1, weight, name));
    }

    @Test
    public void testCompareTo() {
        assertEquals(0, road.compareTo(new Road(town1, town2, weight, name)));
        assertEquals(1, road.compareTo(new Road(town2, town2, weight, name)));
    }

    @Test
    public void testToString() {
    	assertEquals("Test", road.toString());
    }
    
    @After
    public void tearDown() throws Exception {
        road = null;
    }
}