/**
 *
 * @author Ethan Tran
*/

public class Town {
    String name;
    
    public Town(String name) {
        this.name = name;
    }

    public Town(Town templateTown) {
        name = templateTown.name;
    }

    public boolean equals(Object object) {
        if (!(object instanceof Town)) {
            return false;
        }

        Town town = (Town) object;
        return name.equals(town.name);
    }
    
    public int compareTo(Town town) {
    	if (equals (town)) {
    		return 0;
    	} else {
    		return 1;
    	}
    }
    
    public String getName() {
        return name;
    }
    
    public int hashCode() {
    	return name.length();
    }
    
    public String toString() {
        return name;
    }
}