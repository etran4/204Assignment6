import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TownTest_Student {
    private Town town;
    
    @Before
    public void setUp() throws Exception {
        town = new Town("Test");
    }

    @Test
    public void testEquals() {
        assertEquals(town, new Town("Test"));
    }

    @Test
    public void testCompareTo() {
        assertEquals(0, town.compareTo(new Town("Test")));
        assertEquals(1, town.compareTo(new Town("Test1")));
    }

    @Test
    public void testHashCode() {
        assertEquals(4, town.hashCode());
    }
    
    @Test
    public void testToString() {
        assertEquals("Test", town.toString());
    }
    
    @After
    public void tearDown() throws Exception {
        town = null;
    }
}